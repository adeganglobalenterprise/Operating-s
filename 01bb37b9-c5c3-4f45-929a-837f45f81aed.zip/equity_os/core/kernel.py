"""
Equity OS Core Kernel
Universal Operating System for All Devices
Copyright © 2024 Olawale Abdul-Ganiyu
"""

import os
import sys
import json
import hashlib
import platform
from typing import Dict, Any, Optional

class EquityKernel:
    """
    Core kernel of Equity Operating System
    Automatically adjusts to device specifications
    """
    
    def __init__(self):
        self.version = "Universal"  # No version numbers - works for all time
        self.device_info = self._detect_device()
        self.memory_allocation = self._calculate_memory_allocation()
        self.system_state = "booting"
        self.security_level = "maximum"
        self.embedded_protection = True
        
    def _detect_device(self) -> Dict[str, Any]:
        """Detect device specifications automatically"""
        device_info = {
            "platform": platform.system(),
            "machine": platform.machine(),
            "processor": platform.processor(),
            "architecture": platform.architecture(),
            "total_memory": self._get_total_memory(),
            "storage_space": self._get_storage_space()
        }
        return device_info
    
    def _get_total_memory(self) -> int:
        """Get total system memory in bytes"""
        try:
            import psutil
            return psutil.virtual_memory().total
        except ImportError:
            # Fallback estimation
            return 8 * 1024 * 1024 * 1024  # 8GB default
    
    def _get_storage_space(self) -> int:
        """Get available storage space in bytes"""
        try:
            import shutil
            stat = shutil.disk_usage("/")
            return stat.total
        except Exception:
            return 500 * 1024 * 1024 * 1024  # 500GB default
    
    def _calculate_memory_allocation(self) -> Dict[str, int]:
        """
        Automatically allocate 5% of available memory
        Adjusts dynamically based on device specifications
        """
        total_memory = self.device_info["total_memory"]
        allocated_memory = int(total_memory * 0.05)  # Exactly 5%
        
        allocation = {
            "system": allocated_memory,
            "kernel": allocated_memory // 4,
            "ai_engine": allocated_memory // 4,
            "media_processing": allocated_memory // 4,
            "security_layer": allocated_memory // 4
        }
        return allocation
    
    def initialize_system(self) -> bool:
        """Initialize the Equity Operating System"""
        try:
            print(f"\n{'='*60}")
            print(f"EQUITY OPERATING SYSTEM")
            print(f"Universal Version - Works for All Time")
            print(f"Copyright © 2024 Olawale Abdul-Ganiyu")
            print(f"{'='*60}\n")
            
            print(f"Device Detection Complete:")
            print(f"  Platform: {self.device_info['platform']}")
            print(f"  Architecture: {self.device_info['architecture'][0]}")
            print(f"  Memory: {self._format_memory(self.device_info['total_memory'])}")
            print(f"  Storage: {self._format_memory(self.device_info['storage_space'])}")
            print(f"\nMemory Allocation (5%):")
            print(f"  System: {self._format_memory(self.memory_allocation['system'])}")
            print(f"  Kernel: {self._format_memory(self.memory_allocation['kernel'])}")
            print(f"  AI Engine: {self._format_memory(self.memory_allocation['ai_engine'])}")
            print(f"  Media: {self._format_memory(self.memory_allocation['media_processing'])}")
            print(f"  Security: {self._format_memory(self.memory_allocation['security_layer'])}")
            
            self.system_state = "initialized"
            return True
            
        except Exception as e:
            print(f"Initialization Error: {e}")
            return False
    
    def _format_memory(self, bytes_value: int) -> str:
        """Format bytes to human-readable format"""
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if bytes_value < 1024.0:
                return f"{bytes_value:.2f} {unit}"
            bytes_value /= 1024.0
        return f"{bytes_value:.2f} PB"
    
    def get_system_status(self) -> Dict[str, Any]:
        """Get current system status"""
        return {
            "state": self.system_state,
            "device_info": self.device_info,
            "memory_usage": self.memory_allocation,
            "security": self.security_level,
            "embedded_protection": self.embedded_protection
        }
    
    def scan_device(self) -> Dict[str, Any]:
        """
        Comprehensive device scan
        Provides detailed information about the device
        """
        scan_results = {
            "hardware": self.device_info,
            "memory_allocation": self.memory_allocation,
            "system_state": self.system_state,
            "security_status": "active",
            "protection_level": "maximum",
            "compatibility": "universal"
        }
        return scan_results


def main():
    """Main entry point for Equity OS"""
    kernel = EquityKernel()
    
    if kernel.initialize_system():
        print("\n✓ Equity OS initialized successfully!")
        print("✓ Universal compatibility active")
        print("✓ Maximum security enabled")
        print("✓ Embedded protection active")
    else:
        print("\n✗ Initialization failed!")
        sys.exit(1)


if __name__ == "__main__":
    main()