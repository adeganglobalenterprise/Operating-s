"""
Equity OS Installation Packages
Device-specific installation files for all supported platforms
Copyright © 2024 Olawale Abdul-Ganiyu
"""

import os
import json
import subprocess
from typing import Dict, Any, List
from datetime import datetime

class InstallationPackageCreator:
    """
    Create installation packages for different device types
    Each package is optimized for specific device categories
    """
    
    def __init__(self):
        self.package_types = [
            "computer",
            "tablet",
            "mobile",
            "android",
            "apple",
            "tesla",
            "zinex",
            "symbian",
            "memory_device",
            "motherboard",
            "brain_box",
            "human_robot",
            "other_gadget"
        ]
        self.output_dir = "equity_os/install/packages"
        os.makedirs(self.output_dir, exist_ok=True)
        
    def create_installer_script(self, device_type: str) -> str:
        """
        Create installation script for specific device type
        """
        script = f"""#!/bin/bash
# Equity OS Installer for {device_type.upper()}
# Copyright © 2024 Olawale Abdul-Ganiyu
# Universal Version - All Time Compatible

echo "=========================================="
echo "  EQUITY OPERATING SYSTEM INSTALLER"
echo "  Device: {device_type.upper()}"
echo "  Copyright © 2024 Olawale Abdul-Ganiyu"
echo "=========================================="
echo ""

# Check for admin code
echo "Please enter your admin installation code:"
read -s admin_code
echo ""

# Verify admin code (simplified check)
if [ -z "$admin_code" ]; then
    echo "ERROR: Admin code is required for installation"
    exit 1
fi

echo "Admin code accepted. Starting installation..."
echo ""

# Create installation directories
echo "Creating installation directories..."
mkdir -p /equity_os/core
mkdir -p /equity_os/ai
mkdir -p /equity_os/media
mkdir -p /equity_os/security
mkdir -p /equity_os/applications
mkdir -p /equity_os/logs

# Copy system files
echo "Installing system files..."
# (File copying would happen here)

# Run installation wizard
echo "Running installation wizard..."
python3 /equity_os/install/installation_wizard.py

# Create uninstaller
echo "Creating uninstaller..."
cat > /equity_os/uninstall.sh << 'EOF'
#!/bin/bash
echo "Uninstalling Equity OS..."
rm -rf /equity_os
echo "Equity OS uninstalled successfully"
EOF

chmod +x /equity_os/uninstall.sh

# Set permissions
echo "Setting security permissions..."
chmod -R 755 /equity_os
# Additional security settings would go here

echo ""
echo "=========================================="
echo "  INSTALLATION COMPLETE"
echo "=========================================="
echo ""
echo "Equity OS has been successfully installed on your {device_type} device"
echo "Location: /equity_os"
echo ""
echo "Features installed:"
echo "  ✓ Universal compatibility"
echo "  ✓ Embedded security"
echo "  ✓ AI Robot assistant"
echo "  ✓ Media processing"
echo "  ✓ TV/Radio signals"
echo "  ✓ Advanced camera"
echo "  ✓ Custom language"
echo ""
echo "To uninstall, run: /equity_os/uninstall.sh"
echo ""
echo "Thank you for using Equity OS!"
echo "Copyright © 2024 Olawale Abdul-Ganiyu"
"""
        
        return script
    
    def create_windows_installer(self, device_type: str) -> str:
        """Create Windows batch installer"""
        script = f"""@echo off
REM Equity OS Installer for {device_type.upper()}
REM Copyright © 2024 Olawale Abdul-Ganiyu

echo ==========================================
echo   EQUITY OPERATING SYSTEM INSTALLER
echo   Device: {device_type.upper()}
echo   Copyright © 2024 Olawale Abdul-Ganiyu
echo ==========================================
echo.

REM Check for admin code
set /p admin_code="Please enter your admin installation code: "

if "%admin_code%"=="" (
    echo ERROR: Admin code is required for installation
    pause
    exit /b 1
)

echo Admin code accepted. Starting installation...
echo.

REM Create installation directories
echo Creating installation directories...
mkdir C:\\equity_os\\core 2>nul
mkdir C:\\equity_os\\ai 2>nul
mkdir C:\\equity_os\\media 2>nul
mkdir C:\\equity_os\\security 2>nul
mkdir C:\\equity_os\\applications 2>nul
mkdir C:\\equity_os\\logs 2>nul

REM Copy system files
echo Installing system files...

REM Run installation wizard
echo Running installation wizard...
python C:\\equity_os\\install\\installation_wizard.py

REM Create uninstaller
echo Creating uninstaller...
echo @echo off > C:\\equity_os\\uninstall.bat
echo echo Uninstalling Equity OS... >> C:\\equity_os\\uninstall.bat
echo rd /s /q C:\\equity_os >> C:\\equity_os\\uninstall.bat
echo echo Equity OS uninstalled successfully >> C:\\equity_os\\uninstall.bat
echo pause >> C:\\equity_os\\uninstall.bat

REM Set permissions
echo Setting security permissions...
attrib +R C:\\equity_os\\*.* /S

echo.
echo ==========================================
echo   INSTALLATION COMPLETE
echo ==========================================
echo.
echo Equity OS has been successfully installed on your {device_type} device
echo Location: C:\\equity_os
echo.
echo To uninstall, run: C:\\equity_os\\uninstall.bat
echo.
echo Thank you for using Equity OS!
echo Copyright © 2024 Olawale Abdul-Ganiyu
pause
"""
        
        return script
    
    def create_package(self, device_type: str) -> Dict[str, Any]:
        """
        Create complete installation package for device type
        """
        print(f"\nCreating installation package for: {device_type}")
        
        package_info = {
            "device_type": device_type,
            "created": datetime.now().isoformat(),
            "version": "Universal",
            "files": []
        }
        
        # Determine installer type based on device
        if device_type in ["apple", "mobile", "tablet"]:
            # Unix-based systems
            script_content = self.create_installer_script(device_type)
            script_filename = f"install_{device_type}.sh"
        elif device_type in ["computer", "motherboard"]:
            # Try to detect OS or provide both
            script_content_windows = self.create_windows_installer(device_type)
            script_filename_windows = f"install_{device_type}_windows.bat"
            script_content = self.create_installer_script(device_type)
            script_filename = f"install_{device_type}_unix.sh"
        else:
            # Default to Unix
            script_content = self.create_installer_script(device_type)
            script_filename = f"install_{device_type}.sh"
        
        # Save installation scripts
        if device_type in ["computer", "motherboard"]:
            # Save both Windows and Unix scripts
            script_path_windows = os.path.join(self.output_dir, script_filename_windows)
            with open(script_path_windows, 'w') as f:
                f.write(script_content_windows)
            os.chmod(script_path_windows, 0o755)
            package_info["files"].append(script_filename_windows)
        
        script_path = os.path.join(self.output_dir, script_filename)
        with open(script_path, 'w') as f:
            f.write(script_content)
        os.chmod(script_path, 0o755)
        package_info["files"].append(script_filename)
        
        # Create package manifest
        manifest = {
            "package_name": f"equity_os_{device_type}",
            "device_type": device_type,
            "version": "Universal",
            "created": datetime.now().isoformat(),
            "owner": "Olawale Abdul-Ganiyu",
            "files": package_info["files"],
            "installation_instructions": f"Run {script_filename} and follow prompts",
            "requirements": [
                "Admin installation code",
                "Internet connection for AI features",
                "Storage memory (5% will be used)",
                "Compatible device: " + device_type
            ]
        }
        
        manifest_path = os.path.join(self.output_dir, f"manifest_{device_type}.json")
        with open(manifest_path, 'w') as f:
            json.dump(manifest, f, indent=2)
        
        package_info["files"].append(f"manifest_{device_type}.json")
        package_info["manifest"] = manifest
        
        print(f"  ✓ Created installer: {script_filename}")
        print(f"  ✓ Created manifest: manifest_{device_type}.json")
        
        return package_info
    
    def create_all_packages(self) -> List[Dict[str, Any]]:
        """Create installation packages for all device types"""
        print("\n" + "="*60)
        print("CREATING INSTALLATION PACKAGES FOR ALL DEVICES")
        print("="*60)
        
        all_packages = []
        
        for device_type in self.package_types:
            try:
                package = self.create_package(device_type)
                all_packages.append(package)
            except Exception as e:
                print(f"  ✗ Error creating package for {device_type}: {e}")
        
        # Create master package index
        master_index = {
            "total_packages": len(all_packages),
            "supported_devices": self.package_types,
            "packages": all_packages,
            "version": "Universal",
            "owner": "Olawale Abdul-Ganiyu",
            "created": datetime.now().isoformat()
        }
        
        index_path = os.path.join(self.output_dir, "package_index.json")
        with open(index_path, 'w') as f:
            json.dump(master_index, f, indent=2)
        
        print(f"\n✓ Created {len(all_packages)} installation packages")
        print(f"✓ Package index saved: package_index.json")
        
        return all_packages
    
    def display_package_summary(self):
        """Display summary of available packages"""
        print("\n" + "="*60)
        print("INSTALLATION PACKAGES SUMMARY")
        print("="*60)
        
        print(f"\nAvailable installation packages:")
        for i, device_type in enumerate(self.package_types, 1):
            print(f"  {i:2d}. {device_type:20s} - install_{device_type}.sh")
        
        print(f"\nTotal packages: {len(self.package_types)}")
        print(f"Package location: {self.output_dir}")
        print(f"\nInstallation Instructions:")
        print(f"  1. Select the appropriate package for your device")
        print(f"  2. Download the installation script")
        print(f"  3. Run the script on your device")
        print(f"  4. Enter your admin installation code")
        print(f"  5. Follow the on-screen prompts")


def main():
    """Create all installation packages"""
    creator = InstallationPackageCreator()
    
    # Create all packages
    packages = creator.create_all_packages()
    
    # Display summary
    creator.display_package_summary()
    
    print("\n✓ All installation packages created successfully!")


if __name__ == "__main__":
    main()