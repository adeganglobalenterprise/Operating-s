"""
Equity OS Admin Code Generator
Generates installation codes for software distribution
Separate from main software for sale and distribution
Copyright © 2024 Olawale Abdul-Ganiyu
"""

import json
import secrets
import hashlib
from typing import Dict, Any, List
from datetime import datetime

class AdminCodeGenerator:
    """
    Generate admin installation codes
    Format: 1-10 numbers + a-z letters
    Used for software sale and distribution control
    """
    
    def __init__(self):
        self.generated_codes = []
        self.generator_version = "Universal"
        
    def generate_single_code(self) -> Dict[str, Any]:
        """
        Generate a single admin installation code
        Format: 1-10 + a-z (e.g., "7k", "3a", "10z")
        """
        # Generate random number (1-10)
        number_part = secrets.randbelow(10) + 1
        
        # Generate random letter (a-z)
        letter_part = chr(secrets.randbelow(26) + ord('a'))
        
        # Combine to create code
        code = f"{number_part}{letter_part}"
        
        # Generate hash for verification
        code_hash = hashlib.sha256(code.encode()).hexdigest()
        
        # Create code record
        code_record = {
            "code": code,
            "hash": code_hash,
            "generated_at": datetime.now().isoformat(),
            "valid_for": "lifetime",
            "type": "admin_installation",
            "status": "active",
            "uses_remaining": 1  # One-time use
        }
        
        self.generated_codes.append(code_record)
        return code_record
    
    def generate_batch_codes(self, count: int) -> List[Dict[str, Any]]:
        """
        Generate multiple admin codes in batch
        Useful for bulk sales or distribution
        """
        if count <= 0 or count > 10000:
            raise ValueError("Count must be between 1 and 10000")
        
        batch = []
        for _ in range(count):
            batch.append(self.generate_single_code())
        
        return batch
    
    def export_codes_to_file(self, filename: str, codes: List[Dict[str, Any]]) -> bool:
        """
        Export generated codes to a file
        For distribution and record keeping
        """
        try:
            export_data = {
                "export_time": datetime.now().isoformat(),
                "total_codes": len(codes),
                "codes": codes,
                "generator_version": self.generator_version,
                "owner": "Olawale Abdul-Ganiyu"
            }
            
            with open(filename, 'w') as f:
                json.dump(export_data, f, indent=2)
            
            return True
        except Exception as e:
            print(f"Export failed: {e}")
            return False
    
    def generate_sales_report(self) -> Dict[str, Any]:
        """
        Generate sales report based on generated codes
        """
        total_codes = len(self.generated_codes)
        total_value = total_codes * 10  # Assuming $10 per code
        
        report = {
            "report_date": datetime.now().isoformat(),
            "total_codes_generated": total_codes,
            "codes_available": total_codes,
            "estimated_value": total_value,
            "generator_version": self.generator_version,
            "owner": "Olawale Abdul-Ganiyu"
        }
        
        return report
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get statistics about generated codes"""
        if not self.generated_codes:
            return {
                "total_generated": 0,
                "active": 0,
                "used": 0
            }
        
        active_codes = sum(1 for code in self.generated_codes if code["status"] == "active")
        used_codes = sum(1 for code in self.generated_codes if code["status"] == "used")
        
        return {
            "total_generated": len(self.generated_codes),
            "active": active_codes,
            "used": used_codes,
            "available_for_sale": active_codes
        }


def main():
    """Test the admin code generator"""
    print("\n" + "="*60)
    print("EQUITY OS ADMIN CODE GENERATOR")
    print("="*60)
    
    generator = AdminCodeGenerator()
    
    # Generate single code
    print("\nGenerating single code...")
    single_code = generator.generate_single_code()
    print(f"Code: {single_code['code']}")
    print(f"Hash: {single_code['hash'][:20]}...")
    print(f"Generated: {single_code['generated_at']}")
    
    # Generate batch of codes
    print("\nGenerating batch of 5 codes...")
    batch_codes = generator.generate_batch_codes(5)
    print(f"Generated {len(batch_codes)} codes:")
    for code in batch_codes:
        print(f"  - {code['code']}")
    
    # Export codes
    print("\nExporting codes to file...")
    filename = "equity_installation_codes.json"
    if generator.export_codes_to_file(filename, batch_codes):
        print(f"✓ Codes exported to {filename}")
    
    # Statistics
    stats = generator.get_statistics()
    print(f"\nStatistics:")
    print(f"  Total Generated: {stats['total_generated']}")
    print(f"  Active: {stats['active']}")
    print(f"  Available for Sale: {stats['available_for_sale']}")
    
    # Sales report
    report = generator.generate_sales_report()
    print(f"\nSales Report:")
    print(f"  Total Codes: {report['total_codes_generated']}")
    print(f"  Estimated Value: ${report['estimated_value']}")


if __name__ == "__main__":
    main()